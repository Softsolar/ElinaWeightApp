# ElinaWeightApp
Android‑додаток для потижневих вимірів ваги Еліни та графіка з ВОЗ і вертикальними лініями кожного 5‑го числа.
Див. `.github/workflows/android-debug-apk.yml` для автозбірки debug APK.
